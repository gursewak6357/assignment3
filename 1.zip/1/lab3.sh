#!/bin/bash

if [ "$1" == "-verbose" ]; then
    VERBOSITY_FLAG="-verbose"
else
    VERBOSITY_FLAG=""
fi

configure_server() {
    scp "configure-host_v2.sh" "remoteadmin@$1-mgmt:/root"
    ssh "remoteadmin@$1-mgmt" -- "/root/configure-host_v2.sh $VERBOSITY_FLAG -hostname $2 -ipaddress $3 -entry $4 $5"
}

configure_server "server1" "loghost" "192.168.16.3" "webhost" "192.168.16.4"
configure_server "server2" "webhost" "192.168.16.4" "loghost" "192.168.16.3"

./configure-host_v2.sh $VERBOSITY_FLAG -entry "loghost" "192.168.16.3"
./configure-host_v2.sh $VERBOSITY_FLAG -entry "webhost" "192.168.16.4"
