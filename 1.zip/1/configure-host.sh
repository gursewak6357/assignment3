#!/bin/bash
trap '' SIGINT SIGTERM SIGHUP

VERBOSE_FLAG=0
NAME_CHANGED=0
IP_ADJUSTED=0

modify_hostname() {
    target_name="$1"
    if [ "$(hostname)" != "$target_name" ]; then
        echo "$target_name" >/etc/hostname
        hostname "$target_name"
        NAME_CHANGED=1
        logger "Hostname adjusted to $target_name"
    fi
    if [ $VERBOSE_FLAG -eq 1 ]; then
        if [ $NAME_CHANGED -eq 1 ]; then
            echo "Hostname updated to $target_name."
        else
            echo "Hostname remains unchanged."
        fi
    fi
}

update_ip_address() {
    target_ip="$1"
    network_interface=$(ip -4 route list match 0/0 | awk '{print $5}' | head -n 1)
    if [[ $network_interface ]]; then
        if ! ip addr show $network_interface | grep -q $target_ip; then
            sudo ip addr add $target_ip/24 dev $network_interface
            IP_ADJUSTED=1
            logger "IP address set to $target_ip on interface $network_interface"
        fi
    fi
    if [ $VERBOSE_FLAG -eq 1 ]; then
        if [ $IP_ADJUSTED -eq 1 ]; then
            echo "IP address updated to $target_ip."
        else
            echo "IP address remains as is."
        fi
    fi
}

edit_hosts_entry() {
    name="$1"
    ip="$2"
    if ! grep -q "$ip $name" /etc/hosts; then
        echo "$ip $name" >> /etc/hosts
        logger "Added $name with IP $ip to /etc/hosts"
    fi
    if [ $VERBOSE_FLAG -eq 1 ]; then
        echo "Processed /etc/hosts for $name with IP $ip."
    fi
}

while (( "$#" )); do
    case "$1" in
        -verbose) VERBOSE_FLAG=1 ;;
        -hostname) modify_hostname "$2"; shift ;;
        -ipaddress) update_ip_address "$2"; shift ;;
        -entry) edit_hosts_entry "$2" "$3"; shift 2 ;;
    esac
    shift
done
